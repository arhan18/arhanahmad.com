# Astro Portfolio Template

A clean, fast, single-page developer portfolio built with **Astro + Tailwind CSS v4**.
Zero JavaScript shipped. Scores 100/100 on PageSpeed out of the box.

## ✨ Features
- One-file editing — change everything from `src/data.ts`, no code diving
- Light/dark mode (auto via system preference)
- Sections: hero, about + stats, skills, projects, experience timeline, contact
- SEO meta tags ready
- Perfect Lighthouse scores
- Deploys free on Cloudflare Pages / Vercel / Netlify in 2 minutes

## 🚀 Quick start
```bash
npm install
npm run dev      # opens at localhost:4321
npm run build    # outputs static site to dist/
```

## ✏️ Make it yours (5 minutes)
1. Open `src/data.ts`
2. Replace name, role, tagline, projects, experience, email, socials
3. Change `site` URL in `astro.config.mjs`
4. Swap `public/favicon.svg`

That's it. Everything on the page updates automatically.

## 🌐 Deploy free (2 minutes)
**Cloudflare Pages:** push to GitHub → Cloudflare Dashboard → Pages → connect repo → framework preset "Astro" → deploy.
**Vercel/Netlify:** same idea — zero config.

Then set your real domain in `astro.config.mjs`.

## 📄 License
Personal and commercial use allowed for the buyer.
You may NOT resell or redistribute the template itself.

---

Questions? Reach me through my Gumroad page.
