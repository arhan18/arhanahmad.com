// @ts-check
import { defineConfig } from 'astro/config';
import tailwindcss from '@tailwindcss/vite';

export default defineConfig({
  // CHANGE THIS to your domain after deploying
  site: 'https://yourname.dev',
  compressHTML: true,
  build: { inlineStylesheets: 'auto' },
  vite: { plugins: [tailwindcss()] },
});
