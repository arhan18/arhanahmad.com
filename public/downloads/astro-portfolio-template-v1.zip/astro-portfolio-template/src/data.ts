/**
 * ═══════════════════════════════════════════════════
 *  EDIT THIS ONE FILE to make the template yours.
 *  Every section of the site reads from here.
 * ═══════════════════════════════════════════════════
 */

export const site = {
  name: 'Your Name',
  role: 'Full-Stack Developer',
  tagline: 'I build fast, beautiful things for the web.',
  /** Shown in browser tab + Google results */
  seoTitle: 'Your Name — Full-Stack Developer',
  seoDescription:
    'Portfolio of Your Name, a full-stack developer building fast modern web experiences.',
};

export const about = {
  heading: 'About Me',
  paragraphs: [
    'Write your first paragraph here. Who are you, what do you do, and what makes you different? Keep it human.',
    'Second paragraph: your experience, your stack, or what you love building. Two or three short paragraphs is plenty.',
  ],
  stats: [
    { value: '3+', label: 'Years of experience' },
    { value: '20+', label: 'Projects shipped' },
    { value: '10+', label: 'Happy clients' },
  ],
};

export const skills = [
  'JavaScript', 'TypeScript', 'React', 'Astro',
  'Node.js', 'Python', 'Tailwind CSS', 'PostgreSQL',
];

export const projects = [
  {
    title: 'Project One',
    description: 'A short description of the project — what it does and why it matters. Two lines is perfect.',
    tags: ['React', 'API'],
    link: 'https://example.com',
    emoji: '🚀',
  },
  {
    title: 'Project Two',
    description: 'Another project. Replace these entries with your real work — quality over quantity.',
    tags: ['Astro', 'Cloudflare'],
    link: 'https://example.com',
    emoji: '⚡',
  },
  {
    title: 'Project Three',
    description: 'Tip: 4–6 strong projects beat 12 weak ones.',
    tags: ['Node.js', 'PostgreSQL'],
    link: 'https://example.com',
    emoji: '🎯',
  },
];

export const experience = [
  {
    role: 'Your Job Title',
    company: 'Company Name',
    period: '2024 — Present',
    points: ['What you achieved there', 'One more impact point'],
  },
  // Add more entries as needed
];

export const contact = {
  heading: "Let's Work Together",
  blurb: "Have a project in mind? My inbox is always open.",
  email: 'you@example.com',
  socials: [
    { name: 'GitHub', url: 'https://github.com/yourname' },
    { name: 'LinkedIn', url: 'https://linkedin.com/in/yourname' },
    { name: 'Twitter/X', url: 'https://x.com/yourname' },
  ],
};
